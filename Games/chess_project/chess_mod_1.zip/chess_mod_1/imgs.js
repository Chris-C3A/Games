function Imgs() {

	// black pieces
	this.bb = loadImage('https://images.chesscomfiles.com/chess-themes/pieces/preview/60/bb.png');
	this.bk = loadImage('https://images.chesscomfiles.com/chess-themes/pieces/preview/60/bk.png');
	this.bn = loadImage('https://images.chesscomfiles.com/chess-themes/pieces/preview/60/bn.png');
	this.bq = loadImage('https://images.chesscomfiles.com/chess-themes/pieces/preview/60/bq.png');
	this.br = loadImage('https://images.chesscomfiles.com/chess-themes/pieces/preview/60/br.png'); 
	this.bp = loadImage('https://images.chesscomfiles.com/chess-themes/pieces/preview/60/bp.png'); 

	// white pieces

	this.wb = loadImage('https://images.chesscomfiles.com/chess-themes/pieces/preview/60/wb.png');
	this.wk = loadImage('https://images.chesscomfiles.com/chess-themes/pieces/preview/60/wk.png');
	this.wn = loadImage('https://images.chesscomfiles.com/chess-themes/pieces/preview/60/wn.png');
	this.wq = loadImage('https://images.chesscomfiles.com/chess-themes/pieces/preview/60/wq.png');
	this.wr = loadImage('https://images.chesscomfiles.com/chess-themes/pieces/preview/60/wr.png');
	this.wp = loadImage('https://images.chesscomfiles.com/chess-themes/pieces/preview/60/wp.png'); 
}
